The scripts and data reproduce the "AHV Finanzhaushalt" expenditure projections published on 16.09.2024 (see https://www.bsv.admin.ch/bsv/de/home/sozialversicherungen/ahv/finanzen-ahv.html).

Package and software versions:

R 4.3.3
tidyverse 2.0.0
magrittr 2.0.3
simputation 0.2.8
readxl 1.4.3
zoo 1.8-12
tidymodels 1.1.1